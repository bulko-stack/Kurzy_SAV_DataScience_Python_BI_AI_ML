# MojaKnižnica.py
from robot.api.deco import keyword

class MojaKniznica:
    @keyword  # dekorátor sprístupní metódu ako kľúčové slovo
    def povedz_ahoj(self, meno):
        print(f"Ahoj {meno}")
