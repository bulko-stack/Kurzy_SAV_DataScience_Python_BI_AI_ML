from src.matematika import sucet

def test_sucet():
    assert sucet(2, 3) == 5
