def sucet(a, b):
    return a + b
