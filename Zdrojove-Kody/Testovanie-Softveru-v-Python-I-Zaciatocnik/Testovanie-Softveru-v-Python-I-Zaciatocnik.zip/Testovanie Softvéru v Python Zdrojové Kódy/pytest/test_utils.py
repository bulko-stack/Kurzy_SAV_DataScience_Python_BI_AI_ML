from utils import filtruj_parne

def test_filtruj_parne_kladne():
    assert filtruj_parne([2, 4]) == [2, 4]

def test_filtruj_parne_ziadne():
    assert filtruj_parne([1, 3]) == []
